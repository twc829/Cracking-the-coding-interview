Solutions for the book: Cracking the coding interview V4. Written in C++.

See the detailed solutions:

<http://hawstein.com/posts/ctci-solutions-contents.html>
